# OBS, Streamlabs, Discord, Spotify, Sakuraa and ReShade guide

CRIX only changes Gorilla Tag. It **never** changes OBS, Streamlabs, Discord, Spotify, Sakuraa or ReShade settings,
never injects into them, never changes process priorities and never terminates anything. Its interaction with them
is read-only: whether their process runs, whether their DLL is loaded into the game process, and (1.1) OBS's and
Streamlabs' live/recording state through their own local APIs on 127.0.0.1.

## Auto streaming mode (1.1)

With `[Streaming] AutoStreamingMode = true` (default), CRIX switches to `OBSStreaming` while OBS/Streamlabs is live or
recording and to `DiscordCall` while Discord runs, then back to your profile 20 s after the signal ends. Your own
`[General] Profile` setting is not changed. It only switches away from `Balanced`, `OBSStreaming` and `DiscordCall`;
`VirtualDesktop` moves to its Streaming variant; `MaximumPerformance`, `HighRefresh`, `ReShadeCompatible`, `MultiMod`
and `Custom` are kept as you chose them. Setup of the OBS WebSocket (needed to know when OBS is actually live):
[INSTALLATION.md](../INSTALLATION.md#auto-streaming-mode-obs-streamlabs-discord).

| Signal | How CRIX reads it | What it can see |
|---|---|---|
| OBS Studio 28+ | obs-websocket v5 on 127.0.0.1:4455 (your password), requests `GetStreamStatus`/`GetRecordStatus`/`GetReplayBufferStatus`/`GetVirtualCamStatus` and listens to their state events | live / recording / replay buffer / virtual camera / idle |
| OBS without WebSocket | process `obs64`/`obs32` | running only |
| Streamlabs Desktop | its local JSON-RPC API on 127.0.0.1:28194, `StreamingService.getModel` every 2 s | live / recording / replay buffer / idle |
| Discord | process name, or Discord's overlay DLL in the game | running only (calls/Go Live are not readable without injection) |

---

## OBS Studio / Streamlabs (`OBSStreaming` profile)

**What CRIX does:** reduces game-side GPU and CPU work (shadow distance ≤ 30 m, ≤ 2 shadow cascades, ≤ 1
additional/pixel light, no realtime reflections, soft particles off, cosmetic visual updates at 24/s, distant
cosmetics culled a little sooner), smooths frame pacing during loads (1 ms upload slice, lower background-loading
priority) and applies Potassium's stutter fixes. When the VR runtime reports GPU time, adaptive mode keeps 20 % of
the GPU budget free for OBS. It does **not** change the desktop mirror, and adaptive mode may not lower the render
scale in this profile: under URP that scale also sets the resolution of the desktop camera OBS records, so the
captured image keeps its resolution. It warns if the
dashboard is visible while OBS's game-capture hook is loaded (the dashboard would appear on stream).

**What CRIX cannot do:** fix encoder overload, upload bandwidth, dropped network frames, capture-card problems or OBS
scene complexity.

### Reading OBS's own statistics (View → Stats)

| OBS counter | Meaning | Does CRIX help? |
|---|---|---|
| *Frames missed due to rendering lag* | OBS could not compose frames in time; often GPU contention with the game | **Possibly.** Less game GPU load leaves more for OBS. Try `OBSStreaming` or `MaximumPerformance`. |
| *Skipped frames due to encoding lag* | Encoder overloaded | No. Use a hardware encoder, a faster preset or a lower resolution/frame rate in OBS. |
| *Dropped frames (network)* | Upload cannot keep up | No. Lower the bitrate or check your connection. |

OBS-side options worth testing yourself: a hardware encoder (NVENC/AMF/QuickSync), a capture method that suits your
setup (Game Capture of the Gorilla Tag window, Window Capture, or an OpenVR capture plugin), and running OBS as
administrator (OBS documents that this gives its rendering higher GPU priority). CRIX makes none of these changes.

### Recommended routine

1. Profile `OBSStreaming` (or `VirtualDesktop` + preset `Streaming` when you also play over Virtual Desktop).
2. Dashboard **off** while live (F8). Alerts still go to the log.
3. Adaptive quality is on by default (`[Adaptive] Mode = On`, down to `MinimumQualityLevel = -6`). To keep visuals
   closer to the profile while live, raise the floor, e.g. `MinimumQualityLevel = -3`.
4. Record a benchmark (F6) with OBS idle and with OBS recording, and compare (see [BENCHMARKING.md](BENCHMARKING.md)).

---

## Discord (`DiscordCall` profile)

Works the same whether or not Discord is installed. CRIX does not touch calls, audio, the microphone or Discord itself.

**What CRIX does:** modest game-side reductions, so the GPU encoder used for video/screen share and the CPU used for
voice processing have more room: shadow distance ≤ 35 m, ≤ 2 shadow cascades, ≤ 2 pixel/additional lights, no
realtime reflections, soft particles off, cosmetic visual updates at 24/s, smoother loading, and 10 % GPU headroom
for adaptive mode when the VR runtime reports GPU time. If Discord's in-game overlay DLL is loaded into the game, CRIX
mentions it: overlays hook the game's graphics presentation and can add frame-time spikes.

Discord-side options worth testing (all in Discord's own settings; names vary by version): hardware acceleration,
the in-game overlay on/off, and screen-share resolution/frame rate.

---

## Spotify

Detected by process name. Spotify's desktop app uses GPU hardware acceleration by default. If you see stutter while
it plays, turn that off in Spotify's settings (restart Spotify). While Spotify runs, adaptive mode keeps 5% more GPU
headroom. Nothing in Spotify is read or changed.

---

## Sakuraa Client and GTFX

Sakuraa Client is a commercial Gorilla Tag client with camera/casting features. GTFX is its own closed shader/effects
system, injected by Sakuraa's launcher. CRIX:

- detects Sakuraa (assemblies, plugin GUIDs and Harmony patch owners whose name contains "Sakuraa") and lists it in
  the log and system report;
- lists every extra camera (spectator/shoulder camera, minimap, tablet, replay viewer) with its resolution and
  derived pixel load relative to one VR eye, and points out a large desktop camera while you stream;
- reduces the game's own load around Sakuraa as usual.

CRIX does **not** change Sakuraa, GTFX or Sakuraa's own cameras (that would be changing another mod's settings).
Sakuraa's spectator view uses the game's third-person camera; the `DesktopCamera` setting of the HighRefresh profile
therefore leaves that camera on when Sakuraa has taken it over, unless you allow it with
`[Compatibility] DesktopCameraWhenModsUseIt = true` (the spectator view is then shown only while you record or stream). To make
GTFX cheaper, choose a lighter GTFX preset inside Sakuraa while streaming. Sakuraa sets Unity's
`targetFrameRate`/`vSyncCount`; VR runtimes ignore those, and CRIX does not manage them.

Download Sakuraa only from its official source; CRIX does not check where a copy came from.

---

## ReShade (`ReShadeCompatible` profile and the ReShade guard)

ReShade applies post-processing shaders on the graphics API level. Depth-based effects (ambient occlusion, depth of
field, ...) find the game's depth buffer by its size and format. That selection breaks when render targets are
recreated or change format.

**ReShade guard** (`[Compatibility] ReShadeGuard = Auto`, the default): when ReShade is detected (ReShade.ini, a proxy
DLL such as `dxgi.dll` whose version info says ReShade, or a loaded ReShade module), CRIX does not change at runtime:

- MSAA (recreates depth buffers),
- camera HDR (changes render-target formats),
- the desktop mirror (ReShade may be applied to that window),
- render scale through adaptive mode (recreates eye textures). A fixed render scale from the profile is still applied once.

Everything else (shadows, LOD, lights, reflection probes, frame pacing, stutter fixes, cosmetic throttles) keeps
working, so you can trade game-side effects for ReShade's cost. `ReShadeGuard = On` forces the guard without
detection; `Off` disables it (not recommended with depth effects).

The `ReShadeCompatible` profile applies the same constraints and also leaves soft particles and the occlusion mesh
alone.

**Not supported / not guaranteed:** every ReShade shader, every ReShade version, graphics APIs other than the game's
default Direct3D 11 (the system report shows the API in use), VR-specific ReShade builds and add-ons, and any
combination where another mod changes resolution or MSAA. If an effect breaks, set the profile to
`ReShadeCompatible`, restart the game (so render targets are created once with final values), and check that nothing
else changes resolution.

Turning the ReShade mode off is safe at any time: CRIX restores the values it changed. Your ReShade configuration is
never touched.
